//Enemy Blobs
public class Blob {
	
}
